<?php
$base_url = "http://localhost/onlinepastebin/";
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <!-- prism css -->
    <link rel="stylesheet" href="plugin/prism/prism.css">

    <!-- fonts google -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400" rel="stylesheet">

    <link rel="stylesheet" href="plugin/css/sahmura.css">