<nav class="navbar navbar-expand-lg navbar-light shadow-sm sticky-top" style="background: white;">
    <div class="container">
        <a class="navbar-brand" href="<?php echo $base_url; ?>">Online Notepad</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ml-auto">
                <a class="nav-item nav-link" data-scroll href="<?php echo $base_url; ?>#home">Home</a>
                <a class="nav-item nav-link" data-scroll href="<?php echo $base_url; ?>#inputid">Input ID</a>
                <a class="nav-item nav-link" data-scroll href="<?php echo $base_url; ?>#fitur">Features</a>
                <a class="nav-item nav-link" data-scroll href="<?php echo $base_url; ?>new.php">How to use</a>
            </div>
        </div>
    </div>
</nav>