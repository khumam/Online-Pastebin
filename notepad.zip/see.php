<?php
require('database/dbConnect.php');

if (!isset($_GET['id'])) {
    header('location: index.php');
} else {

    require('database/showById.php');

    require('view/header.php');
    ?>

    <title>Judul Catatan</title>
    </head>

    <body>

        <?php include('view/navbar.php'); ?>

        <section>
            <div class="jumbotron jumbotron-fluid bg-whitee" style="height: 100%; width: 100%;">
                <div class="container py-5">
                    <h2><?php echo $data['judul']; ?></h2>
                    <p style="font-size:18px;font-weight: 300;"><b><?php echo $data['author']; ?></b><br><?php echo ucfirst($data['bahasa']); ?><br>Created at : <?php echo $data['date']; ?></p>
                    <pre class="language-<?php echo $data['bahasa']; ?>"><code class="language-<?php echo $data['bahasa']; ?>"><?php echo $data['konten']; ?></code></pre>
                </div>
            </div>
        </section>


        <?php
        require('view/footer.php');
        ?>




    <?php } ?>